-- GrowFund core schema
CREATE TABLE users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 full_name TEXT,
 phone TEXT,
 document_no TEXT,
 created_at TEXT
);
CREATE TABLE wallets (
 user_id INTEGER PRIMARY KEY,
 balance DECIMAL(18,2) DEFAULT 0,
 earnings DECIMAL(18,2) DEFAULT 0
);
CREATE TABLE transactions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER,
 type TEXT,
 amount DECIMAL(18,2),
 channel TEXT,
 status TEXT,
 created_at TEXT
);
CREATE TABLE rate_tiers (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 min_amount DECIMAL(18,2),
 max_amount DECIMAL(18,2),
 annual_rate DECIMAL(8,5),
 name TEXT
);
CREATE TABLE withdrawals (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER,
 amount DECIMAL(18,2),
 channel TEXT,
 status TEXT,
 created_at TEXT
);

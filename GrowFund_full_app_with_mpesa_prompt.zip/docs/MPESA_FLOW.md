# M-Pesa Deposit Flow

1. Customer enters amount and phone number.
2. Frontend sends `POST /api/deposit`.
3. Backend validates the amount and creates a PENDING transaction.
4. Backend calls Safaricom Daraja STK Push using:
   - MPESA_CONSUMER_KEY
   - MPESA_CONSUMER_SECRET
   - MPESA_SHORTCODE
   - MPESA_PASSKEY
   - MPESA_CALLBACK_URL
5. Customer receives the M-Pesa prompt on the phone.
6. Customer enters their M-Pesa PIN.
7. Safaricom sends the result to the callback URL.
8. Backend verifies the callback, matches the checkout/request reference and amount, and marks the transaction CONFIRMED.
9. Only after confirmation should the wallet ledger be credited.

Never credit a real wallet simply because the customer clicked a frontend “payment successful” button.

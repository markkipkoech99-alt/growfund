# GrowFund — Full-stack prototype

## What is included
- Customer website + installable PWA
- Responsive dashboard
- Registration/login API
- SQLite database
- Password hashing + JWT authentication
- Customer wallet/ledger structure
- Deposit transaction workflow
- Withdrawal workflow
- KYC profile fields
- Configurable rate tiers
- Admin deposit-confirmation endpoint
- M-Pesa integration configuration placeholders
- Product/compliance notes

## Run the website
You can open `frontend/index.html` directly for the browser/PWA demo.

For PWA service-worker behavior, serve the frontend from a local web server, for example:
`python -m http.server 8080` inside the frontend directory.

## Run the backend
Requirements: Node.js 18+.

1. `cd backend`
2. `npm install`
3. Copy `.env.example` to `.env`
4. Change `JWT_SECRET` and `ADMIN_KEY`
5. `npm start`

API starts on port 3000 by default.

## Important production architecture
This project deliberately does NOT fake live money movement. A production M-Pesa integration should:
1. Create an STK Push/request using your approved Safaricom Daraja credentials.
2. Store the provider checkout/request reference.
3. Wait for the authenticated provider callback.
4. Verify the callback and amount/account reference.
5. Only then post a CONFIRMED credit to the internal ledger.
6. Make callbacks idempotent so a duplicate callback cannot credit money twice.
7. For withdrawals, create a pending withdrawal and use the approved payout flow; reconcile provider results before finalizing.

## Investment/regulatory note
If this will accept money from the public and promise or market investment returns, do not launch it as though it were a regulated money-market fund until the appropriate Kenyan legal/regulatory structure, licensing/authorization, disclosures, KYC/AML controls, custody/fund-management arrangements, accounting, tax handling, consumer protection, audit logging and data-security requirements have been addressed.

The rates in this prototype are examples only and are not guaranteed returns.

## Next production upgrades
- Safaricom Daraja STK Push + callback
- Secure email/phone OTP
- Full KYC document upload and verification provider
- Admin web console with roles
- Double-entry accounting ledger
- Daily accrual engine and reconciliation jobs
- Statements/CSV/PDF exports
- M-Pesa/bank withdrawal integrations
- Rate management with effective dates
- Audit log
- HTTPS, secrets manager, backups and monitoring
- Android/iOS store builds
